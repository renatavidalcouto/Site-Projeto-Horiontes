<script>
  function msg() {
      alert("Você está inscrita! Aguarde nosso contato :) ")
  }
</script>


